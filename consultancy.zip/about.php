<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>about us</h3>
   <p> <a href="home.php">Home</a> / About </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-img.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>Welcome to Classic Book Centre! Since 2000, we've been a haven for book lovers in Tiruppur. Our shelves brim with timeless classics and contemporary gems, curated with passion. Join our vibrant literary community for personalized recommendations and engaging events. At Classic Book Centre, every page holds a new adventure.</p>
         <p>Our shelves boast a curated collection of timeless classics and contemporary gems, catering to every literary taste.Our knowledgeable staff is dedicated to helping you discover your next favorite read. At Classic Book Centre, we believe in the transformative power of storytelling and strive to foster a love of literature in all who enter our doors. So come on in, grab a cozy chair, and let the journey begin.</p>
         <a href="contact.php" class="btn">Contact Us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">Clients Reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/image.jpg" alt="">
         <p>Shopping at Classic Book Centre online is a breeze! The website is user-friendly, and my orders always arrive promptly.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Arun</h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <p>I love the convenience of shopping for my favorite books from Classic Book Centre's online store. The selection is just as fantastic as in-store!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Suriya</h3>
      </div>

      <div class="box">
      <img src="images/image.jpg" alt="">
         <p>Classic Book Centre's online purchasing experience is seamless. From browsing to checkout, everything is smooth and hassle-free.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Raghul</h3>
      </div>

      <div class="box">
      <img src="images/image.jpg" alt="">
       <p>Even though I can't visit the physical store, Classic Book Centre's online platform still provides that same personalized touch. Their customer service is exceptional.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Saadhana</h3>
      </div>

      <div class="box">
      <img src="images/image.jpg" alt="">
         <p>I've never had any issues with returns or exchanges when shopping at Classic Book Centre online. Their customer support team is responsive and efficient.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Prabha</h3>
      </div>

      <div class="box">
      <img src="images/image.jpg" alt="">
      <p>Shopping online at Classic Book Centre is my go-to for gifts. The shipping is fast, and the packaging is always done with care.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Priya</h3>
      </div>

   </div>

</section>

<section class="authors">

   <h1 class="title">Great Authors</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3> F. Scott Fitzgerald</h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>George Eliot</h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3> Henry Fielding</h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Jane Austen</h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>George Orwell </h3>
      </div>

      <div class="box">
         <img src="images/image.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Preeti Shenoy</h3>
      </div>

   </div>

</section>







<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>